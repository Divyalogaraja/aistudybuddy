import React from "react";
import Markdown from "react-markdown";
import { BookOpen, HelpCircle, GraduationCap, Compass, Sparkles, Star } from "lucide-react";
import { motion } from "motion/react";

interface ExplanationCardProps {
  topic: string;
  explanation: string;
}

export default function ExplanationCard({ topic, explanation }: ExplanationCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="bg-white rounded-3xl p-6 sm:p-10 border border-purple-100 shadow-xl shadow-purple-950/[0.02]"
      id="explanation-card"
    >
      {/* Subject Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-purple-100 mb-8">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-purple-100 flex items-center justify-center text-purple-700 grow-0 shrink-0 shadow-xs border border-purple-200/50">
            <Compass className="w-6 h-6 text-purple-600 animate-spin-pulse" />
          </div>
          <div>
            <span className="inline-block px-2.5 py-0.5 bg-purple-100 text-purple-700 rounded-md text-[10px] font-bold uppercase tracking-widest mb-1">
              Concept Overview
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif font-black leading-tight text-purple-900 tracking-tight capitalize" id="explanation-topic-title">
              {topic}
            </h2>
          </div>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-50 text-purple-800 text-xs font-bold rounded-full self-start sm:self-center border border-purple-100/50">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Bite-sized breakdown</span>
        </div>
      </div>

      {/* Structured simplified content container */}
      <div className="markdown-body text-purple-950/90">
        <Markdown
          components={{
            h1: ({ ...props }) => (
              <h1 className="text-2xl sm:text-3xl font-serif font-black text-purple-900 mt-8 mb-4 flex items-center gap-2 border-b border-purple-50 pb-2" {...props} />
            ),
            h2: ({ ...props }) => (
              <h2 className="text-xl sm:text-2xl font-serif font-bold text-purple-900 mt-6 mb-3 border-b border-purple-100/30 pb-1" {...props} />
            ),
            h3: ({ ...props }) => (
              <h3 className="text-lg sm:text-xl font-serif font-bold text-purple-800 mt-5 mb-2" {...props} />
            ),
            p: ({ ...props }) => (
              <p className="text-purple-950/80 leading-relaxed mb-5 text-sm sm:text-base font-medium" {...props} />
            ),
            ul: ({ ...props }) => (
              <ul className="list-none pl-1 space-y-3 mb-6 text-purple-900/80" {...props} />
            ),
            ol: ({ ...props }) => (
              <ol className="list-decimal pl-5 space-y-3 mb-6 text-purple-900/80 font-medium" {...props} />
            ),
            li: ({ ...props }) => (
              <li className="text-sm sm:text-base font-medium flex items-start gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-2.5 shrink-0" />
                <span>{props.children}</span>
              </li>
            ),
            strong: ({ ...props }) => (
              <strong className="font-bold text-purple-700 underline decoration-purple-200 decoration-2 underline-offset-2" {...props} />
            ),
            code: ({ ...props }) => (
              <code className="bg-purple-100 text-purple-850 px-1.5 py-0.5 rounded-md font-mono text-xs sm:text-sm font-semibold border border-purple-200/40" {...props} />
            ),
            blockquote: ({ ...props }) => (
              <blockquote className="border-l-4 border-purple-500 bg-purple-50/40 pl-5 pr-3 py-4 italic text-purple-950 rounded-r-2xl my-6 text-sm sm:text-base font-serif font-normal relative overflow-hidden" {...props}>
                <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full blur-xl -mr-6 -mt-6" />
                <span className="relative z-10">{props.children}</span>
              </blockquote>
            ),
          }}
        >
          {explanation}
        </Markdown>
      </div>

      {/* Helpful Hint Card at footer */}
      <div className="mt-10 pt-6 border-t border-purple-100 flex items-start gap-3.5 bg-gradient-to-tr from-purple-50/40 to-indigo-50/20 p-5 rounded-2xl border border-purple-100">
        <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
          <HelpCircle className="w-5 h-5 text-purple-600" />
        </div>
        <div className="space-y-0.5">
          <h4 className="text-xs font-bold text-purple-900 uppercase tracking-wider">Buddy's Tip</h4>
          <p className="text-xs text-slate-600 font-medium leading-relaxed">
            Read key concepts closely, then try testing your recollection with the custom trivia on the right side.
            You can generate different subjects anytime by using the reset option at the top.
          </p>
        </div>
      </div>
    </motion.div>
  );
}
