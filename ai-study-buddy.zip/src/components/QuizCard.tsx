import React, { useState } from "react";
import { QuizQuestion } from "../types";
import { CheckCircle, XCircle, Award, ArrowRight, RotateCcw, AlertTriangle, ListChecks, HelpCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface QuizCardProps {
  quiz: QuizQuestion[];
  topic: string;
}

export default function QuizCard({ quiz, topic }: QuizCardProps) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [scores, setScores] = useState<boolean[]>([]); // tracking correct/incorrect for each question
  const [quizCompleted, setQuizCompleted] = useState(false);

  // Store user's selected answers for the summary/review screen
  const [userAnswers, setUserAnswers] = useState<number[]>([]);

  if (!quiz || quiz.length === 0) {
    return (
      <div className="bg-white rounded-3xl p-6 border border-purple-50 flex flex-col items-center justify-center text-center space-y-3">
        <AlertTriangle className="w-8 h-8 text-amber-500 animate-pulse" />
        <p className="text-slate-600 text-sm font-semibold">No questions found for this topic.</p>
      </div>
    );
  }

  const currentQuestion = quiz[currentIdx];

  const handleSelectOption = (optionIndex: number) => {
    if (hasAnswered) return; // Prevent changing answer after submission
    setSelectedOption(optionIndex);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null || hasAnswered) return;

    const isCorrect = selectedOption === currentQuestion.correctAnswer;
    setScores((prev) => [...prev, isCorrect]);
    setUserAnswers((prev) => [...prev, selectedOption]);
    setHasAnswered(true);
  };

  const handleNextQuestion = () => {
    if (currentIdx < quiz.length - 1) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOption(null);
      setHasAnswered(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const handleRestartQuiz = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setHasAnswered(false);
    setScores([]);
    setUserAnswers([]);
    setQuizCompleted(false);
  };

  const correctCount = scores.filter(Boolean).length;
  const percentageScore = Math.round((correctCount / quiz.length) * 100);

  // Score feedback message
  const getFeedbackMessage = () => {
    if (percentageScore === 100) return { title: "Outstanding Genius!", desc: "A perfect score! You have truly fully mastered this topic! Share your wisdom!", emoji: "🏆" };
    if (percentageScore >= 80) return { title: "Fantastic Progress!", desc: "Excellent understanding! Just minor details left to conquer.", emoji: "🌟" };
    if (percentageScore >= 60) return { title: "Great Effort!", desc: "Solid effort! A quick review of the study guide will help you lock down 100%.", emoji: "👍" };
    return { title: "Healthy Practice!", desc: "Good try! Reading the key breakdowns again will help this knowledge stick.", emoji: "📚" };
  };

  const feedback = getFeedbackMessage();

  return (
    <div id="quiz-card-container" className="h-full">
      <AnimatePresence mode="wait">
        {!quizCompleted ? (
          <motion.div
            key="active-quiz"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.4 }}
            className="bg-white rounded-3xl p-6 sm:p-8 border border-purple-100 shadow-xl shadow-purple-950/[0.02] flex flex-col justify-between h-full"
          >
            <div>
              {/* Quiz Header & Indicator */}
              <div className="flex items-center justify-between gap-4 pb-4 border-b border-purple-100 mb-6">
                <div>
                  <h3 className="text-xl font-serif font-bold text-purple-900 uppercase tracking-tight">Quick Quiz</h3>
                  <p className="text-[10px] text-purple-400 font-bold uppercase tracking-widest mt-0.5">Topic: {topic}</p>
                </div>

                <div className="text-right">
                  <span className="text-sm font-bold text-purple-700">
                    {currentIdx + 1}
                  </span>
                  <span className="text-xs text-purple-400 font-mono">
                    /{quiz.length}
                  </span>
                </div>
              </div>

              {/* Progress dots bar */}
              <div className="flex items-center gap-1.5 mb-6" id="quiz-progress-indicator-dots">
                {quiz.map((_, idx) => {
                  let dotColor = "bg-purple-100/70";
                  if (idx === currentIdx) {
                    dotColor = "bg-purple-600 w-6";
                  } else if (idx < scores.length) {
                    dotColor = scores[idx] ? "bg-emerald-500" : "bg-rose-500";
                  }
                  return (
                    <span
                      key={idx}
                      className={`h-1.5 rounded-full transition-all duration-300 ${dotColor} ${
                        idx === currentIdx ? "grow-0" : "grow"
                      }`}
                    />
                  );
                })}
              </div>

              {/* Question Text with float badge */}
              <div className="p-6 rounded-2xl bg-purple-50/50 border border-purple-100 relative mb-6">
                <span className="absolute -left-3 top-6 w-8 h-8 bg-purple-600 text-white rounded-lg flex items-center justify-center font-bold shadow-md shadow-purple-600/10 font-serif">
                  {currentIdx + 1}
                </span>
                
                <h4 className="font-extrabold text-sm sm:text-base text-purple-950 leading-relaxed ml-4">
                  {currentQuestion.question}
                </h4>

                {/* Multiple Choices Grid */}
                <div className="space-y-2.5 ml-4 mt-5" id="quiz-options-list">
                  {currentQuestion.options.map((option, idx) => {
                    const isSelected = selectedOption === idx;
                    const isCorrect = currentQuestion.correctAnswer === idx;
                    
                    let buttonStyle = "border-purple-200 bg-white text-purple-900 hover:bg-purple-100/50 hover:border-purple-300";
                    let iconNode = null;

                    if (hasAnswered) {
                      if (isCorrect) {
                        buttonStyle = "border-emerald-300 bg-emerald-50/75 text-emerald-950 font-bold";
                        iconNode = <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />;
                      } else if (isSelected) {
                        buttonStyle = "border-rose-300 bg-rose-50/75 text-rose-950 font-bold";
                        iconNode = <XCircle className="w-4 h-4 text-rose-600 shrink-0" />;
                      } else {
                        buttonStyle = "border-purple-100 bg-white text-purple-300 opacity-60";
                      }
                    } else if (isSelected) {
                      buttonStyle = "border-2 border-purple-600 bg-purple-100/80 text-purple-950 font-bold";
                    }

                    return (
                      <motion.button
                        key={idx}
                        onClick={() => handleSelectOption(idx)}
                        disabled={hasAnswered}
                        whileHover={!hasAnswered ? { x: 3 } : {}}
                        className={`w-full text-left p-3 rounded-xl border text-xs sm:text-sm transition-all flex items-center justify-between gap-3 cursor-pointer ${buttonStyle}`}
                      >
                        <div className="flex items-center gap-3">
                          <span className={`w-6 h-6 rounded-md text-xs font-bold flex items-center justify-center shrink-0 uppercase transition-all ${
                            isSelected 
                              ? "bg-purple-600 text-white" 
                              : "bg-purple-50 text-purple-500 border border-purple-100"
                          }`}>
                            {String.fromCharCode(65 + idx)}
                          </span>
                          <span>{option}</span>
                        </div>
                        {iconNode}
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              {/* Immediate educational feedback block */}
              {hasAnswered && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`p-4 rounded-xl text-xs sm:text-sm font-medium border my-4 flex items-start gap-2.5 ${
                    selectedOption === currentQuestion.correctAnswer
                      ? "bg-emerald-50/40 text-emerald-950 border-emerald-100/50"
                      : "bg-rose-50/40 text-rose-950 border-rose-100/50"
                  }`}
                  id="quiz-immediate-feedback"
                >
                  <HelpCircle className={`w-5 h-5 shrink-0 mt-0.5 ${
                    selectedOption === currentQuestion.correctAnswer ? "text-emerald-700" : "text-rose-700"
                  }`} />
                  <div>
                    <span className="font-extrabold uppercase text-[10px] tracking-wider block mb-0.5 font-sans">
                      {selectedOption === currentQuestion.correctAnswer ? "Correct! Solution Info" : "Study Reminder"}
                    </span>
                    <p className="leading-relaxed font-sans">{currentQuestion.explanation}</p>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Action buttons footer */}
            <div className="mt-4 pt-4 border-t border-purple-100">
              {!hasAnswered ? (
                <button
                  onClick={handleSubmitAnswer}
                  disabled={selectedOption === null}
                  className="w-full py-4 bg-purple-900 hover:bg-purple-950 text-white font-extrabold text-sm rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed uppercase tracking-wider"
                >
                  Check Answer
                </button>
              ) : (
                <button
                  onClick={handleNextQuestion}
                  className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-sm rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-md shadow-purple-600/10 cursor-pointer"
                >
                  <span>{currentIdx === quiz.length - 1 ? "Finish and Score" : "Next Question"}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.div>
        ) : (
          /* SCOREBOARD RESULTS PANEL */
          <motion.div
            key="scoreboard"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="bg-white rounded-3xl p-6 sm:p-10 border border-purple-100 shadow-xl shadow-purple-950/[0.02]"
            id="quiz-scoreboard"
          >
            <div className="text-center space-y-4 py-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-100 text-purple-700 shadow-sm text-3xl font-serif">
                {feedback.emoji}
              </div>

              <div>
                <span className="text-[10px] font-bold text-purple-600 uppercase tracking-widest bg-purple-100/55 px-3 py-1 rounded-full border border-purple-200/50">
                  Topic Mastery Result
                </span>
                <h3 className="text-2xl sm:text-3xl font-serif font-black text-purple-950 mt-3">
                  {feedback.title}
                </h3>
                <p className="text-xs sm:text-sm text-purple-900/70 mt-1.5 max-w-sm mx-auto font-medium">
                  {feedback.desc}
                </p>
              </div>

              {/* Stats breakdown */}
              <div className="bg-purple-50/50 rounded-2xl p-4 max-w-sm mx-auto grid grid-cols-2 gap-4 border border-purple-100">
                <div className="text-center border-r border-purple-200">
                  <span className="text-3xl font-black text-purple-700 font-serif">
                    {correctCount}/{quiz.length}
                  </span>
                  <p className="text-[10px] font-bold text-purple-400 uppercase tracking-wider mt-0.5">
                    Correct Answers
                  </p>
                </div>
                <div className="text-center">
                  <span className="text-3xl font-black text-purple-950 font-serif">
                    {percentageScore}%
                  </span>
                  <p className="text-[10px] font-bold text-purple-400 uppercase tracking-wider mt-0.5">
                    Mastery Level
                  </p>
                </div>
              </div>

              {/* Question summary visual check */}
              <div className="space-y-3.5 text-left max-w-sm mx-auto pt-2" id="quiz-recap-results">
                <h4 className="text-[10px] font-bold text-purple-450 uppercase tracking-widest px-1">
                  Answers Recap Details
                </h4>
                <div className="space-y-1.5">
                  {quiz.map((q, idx) => (
                    <div
                      key={idx}
                      className="flex items-start justify-between gap-3 p-3 bg-purple-50/30 border border-purple-100/40 rounded-xl text-xs font-semibold"
                    >
                      <div className="flex items-start gap-2 max-w-[80%]">
                        <span className="text-[10px] text-purple-400 mt-0.5 font-mono">Q{idx + 1}.</span>
                        <p className="text-purple-950 font-bold line-clamp-1">{q.question}</p>
                      </div>
                      {scores[idx] ? (
                        <span className="text-emerald-700 flex items-center gap-0.5 select-none text-[10px] font-bold uppercase tracking-wider bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-100/50">
                          Correct
                        </span>
                      ) : (
                        <span className="text-rose-700 flex items-center gap-0.5 select-none text-[10px] font-bold uppercase tracking-wider bg-rose-50 px-1.5 py-0.5 rounded-md border border-rose-100/50">
                          Incorrect
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Re-study or Retake buttons */}
              <div className="pt-4 flex flex-col gap-2">
                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={handleRestartQuiz}
                  className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs sm:text-sm rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-md shadow-purple-600/15 cursor-pointer uppercase tracking-wider"
                  id="quiz-retake-btn"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retake This Quiz</span>
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
