import React from "react";
import { Quote, Sparkles } from "lucide-react";
import { motion } from "motion/react";

interface MotivationalQuoteProps {
  quote: {
    text: string;
    author: string;
  };
}

export default function MotivationalQuote({ quote }: MotivationalQuoteProps) {
  if (!quote || !quote.text) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative overflow-hidden bg-purple-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl shadow-purple-950/10 border border-purple-800"
      id="study-buddy-quote-container"
    >
      {/* Decorative ambient elements */}
      <div className="absolute top-0 right-0 h-full w-1/2 bg-gradient-to-l from-purple-800 to-transparent opacity-50 pointer-events-none"></div>

      <div className="relative z-10 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="bg-white/10 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 backdrop-blur-xs border border-white/5">
            <Sparkles className="w-3 h-3 text-purple-200 fill-purple-100/10" />
            <span>Mindset Booster</span>
          </div>
          <Quote className="w-6 h-6 text-purple-300/30" />
        </div>

        <p className="font-serif italic text-xl leading-relaxed text-purple-100">
          "{quote.text}"
        </p>

        <div className="flex items-center justify-between pt-3 border-t border-purple-800 text-[10px] uppercase font-bold tracking-widest text-purple-300">
          <span>Daily Quote</span>
          <span className="text-white">— {quote.author || "Unknown"}</span>
        </div>
      </div>
    </motion.div>
  );
}
