import React from "react";
import { GraduationCap, RotateCcw, BookOpen, Sparkles } from "lucide-react";
import { motion } from "motion/react";

interface HeaderProps {
  onReset: () => void;
  hasActivePlan: boolean;
  activeTopic?: string;
}

export default function Header({ onReset, hasActivePlan, activeTopic }: HeaderProps) {
  return (
    <header 
      id="app-header"
      className="h-20 border-b border-purple-200 flex items-center justify-between px-4 sm:px-10 bg-white/50 backdrop-blur-md sticky top-0 z-40 shrink-0"
    >
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand logo & mascot */}
        <div className="flex items-center gap-3">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onReset}
            className="cursor-pointer flex items-center justify-center w-10 h-10 rounded-xl bg-purple-600 text-white shadow-md shadow-purple-600/15"
          >
            <GraduationCap className="w-5.5 h-5.5" />
          </motion.div>
          
          <div onClick={onReset} className="cursor-pointer">
            <span className="text-xl font-extrabold tracking-tight text-purple-900 font-sans">
              StudyBuddy<span className="text-purple-500 underline decoration-2 underline-offset-4">AI</span>
            </span>
            <p className="text-[10px] text-purple-400 font-bold uppercase tracking-widest hidden xs:block">
              Editorial Companion
            </p>
          </div>
        </div>

        {/* Dynamic Context and Navigation Actions */}
        <div className="flex items-center gap-4">
          {hasActivePlan && (
            <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-purple-50 rounded-lg text-xs font-semibold text-purple-800 border border-purple-100">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Studying: </span>
              <span className="text-indigo-900 font-bold truncate max-w-[140px] italic">{activeTopic}</span>
            </div>
          )}

          {hasActivePlan && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onReset}
              className="flex items-center gap-1.5 px-4 py-2 border border-purple-200 hover:bg-purple-50 text-purple-700 font-bold text-xs rounded-xl transition-all cursor-pointer bg-white"
              title="Study another topic"
              id="reset-topic-btn"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Topic</span>
            </motion.button>
          )}

          {/* Daily Streak or Profile avatar matching theme design */}
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-[10px] text-purple-400 font-bold uppercase tracking-widest leading-none">Daily Streak</p>
              <p className="text-xs font-bold text-purple-700">12 Days 🔥</p>
            </div>
            <div className="w-9 h-9 rounded-full border-2 border-purple-200 p-0.5 shadow-sm">
              <div className="w-full h-full bg-purple-100 rounded-full flex items-center justify-center font-bold text-xs text-purple-600">
                SB
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
