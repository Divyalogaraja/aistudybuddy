import React, { useState } from "react";
import { Search, Sparkles, BookOpen, Clock, ArrowRight, BookMarked, HelpCircle } from "lucide-react";
import { motion } from "motion/react";

interface TopicSelectorProps {
  onSelectTopic: (topic: string) => void;
  loading: boolean;
  history: string[];
  onClearHistory: () => void;
}

const POPULAR_TOPICS = [
  { name: "Photosynthesis", category: "Science", icon: "🌱", color: "from-green-500 to-emerald-600" },
  { name: "Quantum Computing", category: "Tech", icon: "⚛️", color: "from-cyan-500 to-indigo-600" },
  { name: "Roman Empire", category: "History", icon: "🏛️", color: "from-amber-500 to-red-600" },
  { name: "Global Water Cycle", category: "Earth Science", icon: "💧", color: "from-blue-500 to-cyan-600" },
  { name: "How the Internet Works", category: "Computing", icon: "🌐", color: "from-indigo-500 to-purple-600" },
  { name: "Artificial Intelligence Basics", category: "Tech", icon: "🤖", color: "from-violet-500 to-purple-700" }
];

export default function TopicSelector({ onSelectTopic, loading, history, onClearHistory }: TopicSelectorProps) {
  const [inputValue, setInputValue] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onSelectTopic(inputValue.trim());
    }
  };

  return (
    <div id="topic-selector-container" className="space-y-8 max-w-3xl mx-auto py-6">
      {/* Hero / Welcome Buddy section */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center space-y-4"
      >
        <div className="inline-block px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-bold uppercase tracking-widest mb-2 border border-purple-200">
          <span>Editorial Companion Guide</span>
        </div>

        <h2 className="text-4xl sm:text-5.5xl font-serif font-black leading-tight text-purple-900 tracking-tight">
          What are we <br/>
          <span className="text-purple-600 italic">mastering</span> today?
        </h2>
        
        <p className="text-slate-600 max-w-xl mx-auto text-sm sm:text-base font-medium leading-relaxed">
          Type any complex academic or creative topic below. We'll instantly break it down into clean, 
          magazine-grade simplified explanations, challenge your recall, and boost your mindset.
        </p>
      </motion.div>

      {/* Main Search Bar Form */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1, duration: 0.4 }}
        className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl shadow-purple-950/[0.03] border border-purple-100/80"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-purple-400">
              <Search className="w-5.5 h-5.5" />
            </div>
            <input
              type="text"
              required
              disabled={loading}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Enter any topic (e.g., Quantum Entanglement, Black Holes, Deep Memory)..."
              className="w-full bg-purple-50/50 hover:bg-purple-50/80 focus:bg-white border-2 border-purple-100/60 focus:border-purple-500 rounded-2xl py-4 pl-12 pr-4 outline-hidden text-sm sm:text-base font-semibold text-purple-900 placeholder:text-purple-300 transition-all disabled:opacity-60"
              id="topic-search-input"
            />
          </div>

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            type="submit"
            disabled={loading || !inputValue.trim()}
            className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-sm sm:text-base rounded-2xl shadow-lg shadow-purple-600/15 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed text-center"
            id="topic-generate-submit"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Assembling Study Guide...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-purple-200 fill-purple-100/20" />
                <span>Explain Topic & Quiz Me</span>
              </>
            )}
          </motion.button>
        </form>
      </motion.div>

      {/* Pre-seeded Suggestions Grid */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold text-purple-400 uppercase tracking-widest flex items-center gap-1.5 px-1">
          <BookOpen className="w-3.5 h-3.5 text-purple-400" />
          <span>Curated Concept Overviews</span>
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="popular-topics-grid">
          {POPULAR_TOPICS.map((topic, idx) => (
            <motion.button
              key={topic.name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * idx + 0.2 }}
              onClick={() => onSelectTopic(topic.name)}
              disabled={loading}
              whileHover={{ y: -2, scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              className="group text-left p-5 bg-white hover:bg-purple-50/10 border border-purple-100 hover:border-purple-300 rounded-2xl shadow-xs transition-all duration-200 cursor-pointer flex items-center justify-between disabled:opacity-60"
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl w-11 h-11 rounded-xl bg-purple-50 group-hover:bg-purple-100 flex items-center justify-center transition-colors">
                  {topic.icon}
                </span>
                <div>
                  <h4 className="font-extrabold text-sm sm:text-base text-purple-950 group-hover:text-purple-700 transition-colors">
                    {topic.name}
                  </h4>
                  <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider bg-purple-50 group-hover:bg-purple-100 px-1.5 py-0.5 rounded-md transition-colors border border-purple-100/50">
                    {topic.category}
                  </span>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-purple-300 group-hover:text-purple-600 group-hover:translate-x-1 transition-all" />
            </motion.button>
          ))}
        </div>
      </div>

      {/* Historical Topics persistence menu */}
      {history.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-3 pt-4 border-t border-slate-100"
        >
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-purple-400" />
              <span>Your Recent Journeys</span>
            </h3>
            <button 
              onClick={onClearHistory}
              className="text-[10px] font-bold text-rose-500 hover:text-rose-600 transition-colors uppercase cursor-pointer tracking-wider"
            >
              Clear History
            </button>
          </div>

          <div className="flex flex-wrap gap-2" id="topic-history-chips">
            {history.map((histTopic) => (
              <motion.button
                key={histTopic}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onSelectTopic(histTopic)}
                disabled={loading}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-purple-50 border border-slate-200/60 hover:border-purple-200 text-xs font-semibold text-slate-700 hover:text-purple-800 rounded-xl cursor-pointer transition-colors disabled:opacity-60"
              >
                <span>{histTopic}</span>
              </motion.button>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
