export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number; // index 0-3
  explanation: string;
}

export interface StudyPlan {
  topic: string;
  explanation: string; // Dynamic rich Markdown/HTML text explaining the topic simply
  quiz: QuizQuestion[];
  quote: {
    text: string;
    author: string;
  };
}
