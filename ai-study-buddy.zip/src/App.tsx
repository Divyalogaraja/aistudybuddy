import React, { useState, useEffect } from "react";
import { StudyPlan } from "./types";
import Header from "./components/Header";
import TopicSelector from "./components/TopicSelector";
import ExplanationCard from "./components/ExplanationCard";
import QuizCard from "./components/QuizCard";
import MotivationalQuote from "./components/MotivationalQuote";
import { 
  Sparkles, 
  HelpCircle, 
  AlertTriangle, 
  ArrowLeft, 
  RefreshCw,
  Award,
  BookOpen,
  ListRestart
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const LOADING_STEPS = [
  "Connecting to tutoring agent...",
  "Formatting friendly educational bytes...",
  "Drafting interactive quiz challenges...",
  "Gathering inspirational motivational cues...",
  "Polishing your custom lesson layout..."
];

export default function App() {
  const [activePlan, setActivePlan] = useState<StudyPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>([]);
  const [selectedTopic, setSelectedTopic] = useState("");

  // Load history from localStorage on mounting
  useEffect(() => {
    try {
      const saved = localStorage.getItem("ai-study-buddy-history");
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Failed to load search history", e);
    }
  }, []);

  // Roam through loading messages when working
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (loading) {
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev + 1) % LOADING_STEPS.length);
      }, 2000);
    } else {
      setLoadingStep(0);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleSelectTopic = async (topicName: string) => {
    if (!topicName || topicName.trim().length === 0) return;
    
    setLoading(true);
    setError(null);
    setSelectedTopic(topicName);

    try {
      const response = await fetch("/api/study", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ topic: topicName })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Server responded with status code ${response.status}`);
      }

      const plan: StudyPlan = await response.json();
      setActivePlan(plan);

      // Persist searched topic name to local history
      setHistory((prev) => {
        const filtered = prev.filter((t) => t.toLowerCase() !== topicName.toLowerCase());
        const updated = [topicName, ...filtered].slice(0, 10); // keep max 10
        localStorage.setItem("ai-study-buddy-history", JSON.stringify(updated));
        return updated;
      });
    } catch (err: any) {
      console.error("Study generation failed:", err);
      setError(err.message || "An unexpected error occurred. Please check your network and try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setActivePlan(null);
    setError(null);
    setSelectedTopic("");
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem("ai-study-buddy-history");
  };

  return (
    <div className="min-h-screen bg-[#F9F7FF] flex flex-col selection:bg-purple-200 selection:text-purple-900" id="study-buddy-root">
      {/* Top Navigation */}
      <Header 
        onReset={handleReset} 
        hasActivePlan={!!activePlan} 
        activeTopic={activePlan?.topic || selectedTopic} 
      />

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8 sm:px-10 lg:px-12">
        <AnimatePresence mode="wait">
          {/* 1. LOADING SCREEN VIEW */}
          {loading && (
            <motion.div
              key="loading-screen"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-col items-center justify-center py-20 text-center max-w-md mx-auto space-y-6"
              id="study-buddy-loading"
            >
              <div className="relative">
                {/* Outer spin ring */}
                <div className="absolute inset-0 rounded-full border-4 border-purple-100 animate-pulse" />
                <div className="w-16 h-16 rounded-full border-t-4 border-b-4 border-purple-600 animate-spin flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-purple-600 animate-pulse" />
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-serif font-black text-2xl text-purple-950">
                  Curating Study Guide
                </h3>
                <p className="text-xs sm:text-sm font-semibold text-purple-700 min-h-[20px] transition-all duration-300">
                  {LOADING_STEPS[loadingStep]}
                </p>
                <p className="text-xs text-purple-400 font-medium leading-relaxed">
                  We are summarizing concepts into high-grade breakdowns. This takes only a moment!
                </p>
              </div>
            </motion.div>
          )}

          {/* 2. ERROR DISPLAY VIEW */}
          {!loading && error && (
            <motion.div
              key="error-screen"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-md mx-auto bg-white rounded-3xl p-6 sm:p-8 border border-rose-100 shadow-xl shadow-rose-900/[0.03] space-y-5"
              id="study-buddy-error"
            >
              <div className="flex items-center gap-3.5 pb-4 border-b border-rose-100">
                <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5.5 h-5.5" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-rose-950 text-base">A Study Jam Occurred</h3>
                  <p className="text-[10px] uppercase font-bold text-rose-405 tracking-widest">Failed Connection</p>
                </div>
              </div>

              <p className="text-rose-950 font-medium text-xs sm:text-sm leading-relaxed bg-rose-50/30 p-4 rounded-xl border border-rose-150">
                {error}
              </p>

              {/* Informative tutorial if Gemini API key is missing */}
              {error.toLowerCase().includes("api_key") && (
                <div className="p-4 bg-purple-50 rounded-xl text-xs space-y-2 text-purple-950 border border-purple-100">
                  <span className="font-bold uppercase tracking-wider text-[10px] block">How to configure:</span>
                  <p className="font-medium leading-relaxed">
                    We've set up your API key automatically, but if you need to modify it: go to the upper right 
                    corner, open the <strong>Settings &gt; Secrets</strong> panel, and click on <strong>GEMINI_API_KEY</strong> 
                    to enter your secret token.
                  </p>
                </div>
              )}

              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => handleSelectTopic(selectedTopic)}
                  className="flex-1 py-3 bg-purple-900 hover:bg-purple-950 text-white font-extrabold text-xs sm:text-sm rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Retry Topic</span>
                </button>
                <button
                  onClick={handleReset}
                  className="px-4 py-3 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer border border-purple-200"
                >
                  Go Back
                </button>
              </div>
            </motion.div>
          )}

          {/* 3. INACTIVE / BLANK STATE: GET TOPIC */}
          {!loading && !error && !activePlan && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <TopicSelector 
                onSelectTopic={handleSelectTopic} 
                loading={loading}
                history={history}
                onClearHistory={handleClearHistory}
              />
            </motion.div>
          )}

          {/* 4. ACTIVE PLAN PRESENTATION VIEW: STUDY HUB */}
          {!loading && !error && activePlan && (
            <motion.div
              key="study-hub"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
              id="study-hub-view"
            >
              {/* Back navigation line */}
              <div className="flex items-center justify-between">
                <button
                  onClick={handleReset}
                  className="inline-flex items-center gap-2 text-xs font-bold text-purple-700 hover:text-purple-900 transition-colors cursor-pointer group"
                  id="go-back-dashboard-btn"
                >
                  <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                  <span>Explore another topic</span>
                </button>

                <div className="text-purple-600 font-bold text-xs flex items-center gap-1 uppercase tracking-widest">
                  <Award className="w-4 h-4" />
                  <span>Curated session</span>
                </div>
              </div>

              {/* Master layout panel */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* LEFT COLUMN: Simplified concepts description (60% width) */}
                <section className="lg:col-span-7 xl:col-span-8 h-full">
                  <ExplanationCard 
                    topic={activePlan.topic} 
                    explanation={activePlan.explanation} 
                  />
                </section>

                {/* RIGHT COLUMN: Zen motivation & MCQ Quiz card (40% width) */}
                <aside className="lg:col-span-5 xl:col-span-4 space-y-6 lg:sticky lg:top-24">
                  {/* Inspirational Booster */}
                  <MotivationalQuote quote={activePlan.quote} />

                  {/* Knowledge test checklist */}
                  <QuizCard quiz={activePlan.quiz} topic={activePlan.topic} />
                </aside>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Styled static margin disclaimer */}
      <footer className="w-full border-t border-purple-200/50 py-6 text-center mt-12 bg-white/40">
        <p className="text-xs text-purple-400 font-semibold uppercase tracking-widest">
          StudyBuddyAI 🎓 — Your instant interactive study companion.
        </p>
      </footer>
    </div>
  );
}
